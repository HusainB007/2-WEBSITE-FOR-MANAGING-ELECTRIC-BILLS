<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="signup.css">
</head>
<body>
     <!-- PHP FOR POST -->
     <?php
      if ($_SERVER['REQUEST_METHOD']=='POST'){
        $email=$_POST['uname'];
        $password1=$_POST['psw'];
      

$servername= "localhost";
$username= "root";
$password= ""; 
$database="electric";

// creating connection
$conn=mysqli_connect($servername,$username,$password,$database);

$sql= "INSERT INTO `electric_login` (`user_id`,`username`, `password`) VALUES ('',$email', '$password1')";

$result=mysqli_query($conn,$sql);
if ($result){
    echo ' Record successfully added';
    echo' <div class="alert alert-success alert-dismissible fade show" role="alert">
    Your username '.$email.' and password '.$password1.' has been submitted successfully Please open the login page and enter your credentials to gain access
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
     </button>
  </div>';
}
else{
  echo "Record not added due to this error ". mysqli_error($conn);
}
      }
?>

    <div class="imgcontainer">
        <img src="newgadget1.png" alt="..." class="avatar">
      </div>
      <form action="/myproject/signupelectric.php" method="post">
    <div class="container">
        <h1>Sign Up</h1>
        <p>Please fill in this form to create an account.</p>
        <hr>
        <label for="uname"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="uname" required>
    
        <label for="psw" ><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="psw" required>

        <label for="pswrepeat" ><b> Repeat Password</b></label>
        <input type="password" placeholder="Repeat Password" name="pswrepeat" required>

            
        <button type="submit" class="login">Login</button>
        <label>
          <input type="checkbox" checked="checked" name="remember" > Remember me
        </label>
      </div>
      <p>By creating an account you 
          agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>
      <div class="container" style="background-color:#f1f1f1">
        <button type="button" class="cancelbtn">Cancel</button>
    </form>
      </div>
</body>
</html>