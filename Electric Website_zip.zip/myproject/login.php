<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">



    a.button {
    border: 1px solid #808080;
    background: #a0a0a0;
    display: inline-block;
    padding: 5px;
}


  </head>
<body>
    <!-- PHP FOR POST -->
    
    <?php
    $insert=FALSE;
      if ($_SERVER['REQUEST_METHOD']=='POST'){
        $email=$_POST['uname'];
        $password1=$_POST['psw'];
      

$servername= "localhost";
$username= "root";
$password= ""; 
$database="logininfo";

// creating connection
$conn=mysqli_connect($servername,$username,$password,$database);

// $sql= "INSERT INTO `logintable` (`user_id`,`username`, `password`) VALUES ('23','$email', '$password')";
// $result=mysqli_query($conn,$sql);
// if ($result){
//     echo ' Record successfully added';
//     echo" <div class="alert alert-success alert-dismissible fade show" role='alert'>
//     Your username '.$email.' and password '.$password.' has been submitted successfully
//     <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'>
//     <span aria-hidden='true'>&times;</span>
//      </button>
//   </div>";
// }
// else{
//   echo "Record not added due to this error ". mysqli_error($conn);
// }

//$sql="SELECT * FROM `logintable` WHERE  `logintable`.`username`=$email and `logintable`.`password`=$password";

$sql="SELECT COUNT(1) FROM `logintable` WHERE `logintable`.`password` = $password1";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_row($result);

if ($row[0]>=1){
  echo " YOU HAVE ACCESS TO THE WEBSITE -> PLEASE CLICK THE HOME BUTTON TO GO TO THE MAIN PAGE";
  echo  `<button type="submit" class="home" >HOME</button>`;
  echo `<a class="button" href="localhost/myproject/putinsql.php" target="_blank">New Discussion</a>`;
  echo " <div class='alert alert-success alert-dismissible fade show' role='alert'>
    Your username '.$email.' and password '.$password.' has been submitted successfully
       <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'>
       <span aria-hidden='true'>&times;</span>
        </button>
     </div> ";
  $insert=TRUE;
  // <a href= "husain.html">
  //     <button>HOME</button>
  //   </a>
  //<button type="submit" class="home" >HOME</button>;

  //<li><a class="active" href="#home">Home</a></li>
  //Response.Redirect("signup.php");
// ---------------------------------------
  // COOKIE SYNTAX
  // setcookie("category","laptop",time()+86400,"/");
  // in husain.php page write this:
  // $cat=$_COOKIE['category'];
  // -----------------------------

//   SESSION SYNTAX
//   IN LOGIN PAGE TO STORE SESSION VARIABLE:
//   session_start();
//   $_SESSION['favcat']='laptop';
//   echo 'saved session';

//   IN husain.html to get the values of session
// put on top of html
//   session_start();
// if isset($_SESSION['username']){

  //   echo 'Welcome '.$_SESSION['username'];
//   //  echo 'your fav cat is' . $_SESSION['favcat'];
// }else{
//   echo 'please log in'
// }
// TO DESTROY SESSION: 
// session_unset()
// session_destroy()


// ----------------------------------------------------
}
else{
  echo ' USERNAME OR PASSWORD NOT FOUND ';
}
      }
      ?>
    
      <!-- TILL HERE POST -->

    <div class="imgcontainer">
        <img src="newgadget1.png" alt="..." class="avatar">
      </div>

    

<form action="/myproject/login.php" method="post">
    <div class="container">
        <label for="uname"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="uname" id="uname" required>
    
        <label for="psw" ><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="psw" id="psw" required>
            
        <button type="submit" class="login">Login</button>
        <?php
if($insert){
  echo "hi this is just a test";
}
        ?>
        <label>
          <input type="checkbox" checked="checked" name="remember" > Remember me
        </label>
        </form>
      </div>
      

      
    
      <div class="container" style="background-color:#f1f1f1">
        <button type="button" class="cancelbtn">Cancel</button>
       
        <span class="psw">Forgot <a href="#">password?</a></span>
      </div>
    
    
</body>
</html>