<?php
echo' hello ';

// connecting to db
$servername= "localhost";
$username= "root";
$password= ""; 

// creating connection
$conn=mysqli_connect($servername,$username,$password);

// CREATE A DB
$sql="CREATE DATABASE dbhusain_new_1";
mysqli_query($conn,$sql);


if ($conn){
    echo ' successfully';
}
?>