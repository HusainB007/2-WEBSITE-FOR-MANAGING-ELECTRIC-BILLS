<?php
echo' hello ';

// connecting to db
$servername= "localhost";
$username= "root";
$password= ""; 
$database="logininfo";

// creating connection
$conn=mysqli_connect($servername,$username,$password,$database);

// No of affected rows on updation query use-> $aff->mysqli_affected_rows($conn)
// $sql= "SELECT * FROM `logintable`";
$sql="SELECT * FROM `logintable` WHERE `logintable`.`password`=123";
$result=mysqli_query($conn,$sql);
$nums=mysqli_num_rows($result);
echo $nums;

while($row=mysqli_fetch_assoc($result)){
    echo var_dump($row);
    echo "<br>";
}
?>