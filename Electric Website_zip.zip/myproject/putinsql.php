<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
<?php
    $insert=FALSE;
      if ($_SERVER['REQUEST_METHOD']=='POST'){
        $email_1=$_POST['uname'];
        $password_1=$_POST['psw'];
        $ampaid_1=$_POST['ampaid'];
        $ampend_1=$_POST['ampend'];
        $addr_1=$_POST['addr'];
        $scheme_1=$_POST['scheme'];
      

$servername= "localhost";
$username= "root";
$password= ""; 
$database="electric";

// creating connection
$conn=mysqli_connect($servername,$username,$password,$database);

$sql= "INSERT INTO `electric_info` (`User_id`, `Amount_paid`, `Amount_pending`, `Address`, `Scheme`) VALUES ('', '$ampaid_1', '$ampend_1', '$addr_1', '$scheme_1')";
$result=mysqli_query($conn,$sql);
if ($result){
    echo ' Record successfully added';
    echo' <div class="alert alert-success alert-dismissible fade show" role="alert">
    Your username  and password '.$password.' has been submitted successfully Please open the login page and enter your credentials to gain access
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
     </button>
  </div>';


  $insert=TRUE;
}
else{
  echo "Record not added due to this error ". mysqli_error($conn);
}
        }
  ?>




<form action="/myproject/putinsql.php" method="post">
<div class="container">
        <label for="uname"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="uname" id="uname" required>
    
        <label for="psw" ><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="psw" id="psw" required>

        <label for="ampaid"><b>Amount_paid</b></label>
        <input type="text" placeholder="Enter Amount paid" name="ampaid" id="ampaid" required>
    
        <label for="ampend" ><b>Amount_pending</b></label>
        <input type="text" placeholder="Enter Amount still pending" name="ampend" id="ampend" required>

        <label for="addr"><b>Address</b></label>
        <input type="text" placeholder="Enter Address" name="addr" id="addr" required>
    
        <label for="scheme" ><b>Scheme</b></label>
        <input type="text" placeholder="Enter your chosen Scheme" name="scheme" id="scheme" required>
            
        <button type="submit" class="login">Login</button>
        <?php
if($insert)
{
  $sql1="SELECT `electric_info`.`User_id` FROM `electric_info` WHERE `electric_info`.`Amount_paid` = '$ampaid_1' AND  `electric_info`.`Amount_pending`='$ampend_1' ";
  $result1=mysqli_query($conn,$sql1);
  echo "YOUR UNIQUE USER ID IS:"."<br>";
  print_r($result1->fetch_all());
  
  
}
        ?>
        
        </form>
        </div>
</body>
</html>