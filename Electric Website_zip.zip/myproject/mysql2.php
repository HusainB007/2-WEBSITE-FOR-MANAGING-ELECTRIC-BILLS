<?php
echo' hello ';

// connecting to db
$servername= "localhost";
$username= "root";
$password= ""; 
$database="logininfo";

// creating connection
$conn=mysqli_connect($servername,$username,$password,$database);
// CREATING TABLE
// $sql="CREATE TABLE....."
// $result=mysqli_query($conn,$sql);

// ADDING RECORD IN LOGINTABLE IN LOGININFO DB
$name="Bamboo";
$pass="Blab";
$sql= "INSERT INTO `logintable` (`username`, `password`) VALUES ('$name', '$pass')";
$result=mysqli_query($conn,$sql);
if ($result){
    echo ' successfully added';
}

?>